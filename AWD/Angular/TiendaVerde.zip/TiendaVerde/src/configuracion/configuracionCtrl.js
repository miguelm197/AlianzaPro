app.controller("configuracionCtrl", ["$scope", "FacConfiguracion", "$location", function ($scope, FacConfiguracion, $location) {

}]);
