app.factory("FacConfiguracion", ["$http", '$cookies', '$rootScope', function ($http, $cookies, $rootScope) {
    return {}
}]);