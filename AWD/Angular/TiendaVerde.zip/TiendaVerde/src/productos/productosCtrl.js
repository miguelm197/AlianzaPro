app.controller("productosCtrl", ["$scope", "$location", function ($scope, $location) {

   
    // alerta("Mensaje", "Productossss", "asoifja sfiujasfiuoja sfiuhasf");
}]);